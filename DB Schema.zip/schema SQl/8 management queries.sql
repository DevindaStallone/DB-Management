SELECT u.UserId, u.FullName,
CONCAT(u.City,', ',u.Country) AS Location, u.Address
FROM user AS u
ORDER BY FullName;

SELECT u.Fullname, w.YearOfExperience
FROM work_experience w INNER JOIN user u ON w.experienceId = u.userId;

SELECT u.Fullname, e.University, e.Degree
FROM Education e INNER JOIN user u ON e.EducationId = u.userId;

SELECT FullName, CONCAT (City, ',', Country) AS Location FROM user;

SELECT administrator.AdministratorID, user.FullName 
FROM administrator INNER JOIN user ON administrator.AdministratorID= user.UserId;

SELECT w.ExperienceId, w.CompanyName, w.Position, w.YearOfExperience, w.JobName, e.University, e.Degree
FROM Work_experience w
LEFT OUTER JOIN education e ON w.ExperienceID=e.EducationID
ORDER BY w.CompanyName;

SELECT p.Fullname, f. FeedId, f.PostUsername, f.PostTitle, f.PostDescription, f.PostDate, PostComments
FROM user_profile p
LEFT JOIN feed f
ON p. UserProfileId =f.FeedId;

SELECT a.AdministratorId, e.EmailTitle, e.EmailContent
FROM administrator a
LEFT JOIN bulk_email e
ON a.AdministratorID=e.EmailId
