-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: abc_jobs
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `feed`
--

DROP TABLE IF EXISTS `feed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feed` (
  `FeedId` int NOT NULL AUTO_INCREMENT,
  `PostUsername` varchar(45) NOT NULL,
  `PostTitle` varchar(45) NOT NULL,
  `PostDescription` varchar(60) NOT NULL,
  `PostDate` datetime NOT NULL,
  `PostComments` varchar(45) NOT NULL,
  PRIMARY KEY (`FeedId`),
  UNIQUE KEY `Feed Id_UNIQUE` (`FeedId`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feed`
--

LOCK TABLES `feed` WRITE;
/*!40000 ALTER TABLE `feed` DISABLE KEYS */;
INSERT INTO `feed` VALUES (1,'ebartosiak0','curabitur','pulvinar sed nisl nunc','2022-02-20 00:00:00','sit amet'),(2,'mdawtry1','tortor','ante ipsum primis in','2022-08-05 00:00:00','nec euismod'),(3,'llongford2','massa','dui luctus rutrum nulla','2022-05-21 00:00:00','facilisi cras'),(4,'tgoard3','habitasse','nunc vestibulum ante ipsum','2022-07-07 00:00:00','donec diam'),(5,'ccolumbine4','aliquam','at turpis a pede','2022-03-31 00:00:00','ut odio'),(6,'dgerrish5','ut','dui luctus rutrum nulla','2022-09-09 00:00:00','vestibulum vestibulum'),(7,'eembury6','risus','turpis sed ante vivamus','2022-02-24 00:00:00','fusce congue'),(8,'srobic7','augue','erat quisque erat eros','2022-08-10 00:00:00','augue a'),(9,'kevason8','consequat','suscipit nulla elit ac','2022-10-16 00:00:00','quisque arcu'),(10,'dales9','pede','dapibus at diam nam','2022-03-21 00:00:00','rhoncus mauris');
/*!40000 ALTER TABLE `feed` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-31 15:07:03
