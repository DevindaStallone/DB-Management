CREATE TABLE User
(
  Email VARCHAR(60) NOT NULL,
  Password VARCHAR(20) NOT NULL,
  User_ID INT NOT NULL,
  Full_name VARCHAR(60) NOT NULL,
  Address VARCHAR(60) NOT NULL,
  Mobile_Number INT NOT NULL,
  Gender VARCHAR(20) NOT NULL,
  Country VARCHAR(20) NOT NULL,
  City VARCHAR(20) NOT NULL,
  DOB DATE NOT NULL,
  PRIMARY KEY (User_ID)
);

CREATE TABLE Feed
(
  Post_username VARCHAR(60) NOT NULL,
  Post_date DATE NOT NULL,
  Post_title VARCHAR(60) NOT NULL,
  Post_description VARCHAR(60) NOT NULL,
  Post_comments VARCHAR(60) NOT NULL,
  Feed_ID INT NOT NULL,
  User_ID INT NOT NULL,
  PRIMARY KEY (Feed_ID),
  FOREIGN KEY (User_ID) REFERENCES User(User_ID)
);

CREATE TABLE Message
(
  Message_title VARCHAR(60) NOT NULL,
  message_description VARCHAR(60) NOT NULL,
  message_users_name VARCHAR(20) NOT NULL,
  Message_ID INT NOT NULL,
  User_ID INT NOT NULL,
  PRIMARY KEY (Message_ID),
  FOREIGN KEY (User_ID) REFERENCES User(User_ID)
);

CREATE TABLE Jobs
(
  Salary INT NOT NULL,
  Experience_requirement INT NOT NULL,
  Job_description VARCHAR(60) NOT NULL,
  Job_Name VARCHAR(60) NOT NULL,
  Company_name VARCHAR(60) NOT NULL,
  Age_limit INT NOT NULL,
  Jobs_ID INT NOT NULL,
  User_ID INT NOT NULL,
  PRIMARY KEY (Jobs_ID),
  FOREIGN KEY (User_ID) REFERENCES User(User_ID)
);

CREATE TABLE User_Profile
(
  full_name VARCHAR(60) NOT NULL,
  Address VARCHAR(60) NOT NULL,
  Gender VARCHAR(20) NOT NULL,
  Profile_picture VARCHAR(60) NOT NULL,
  city VARCHAR(20) NOT NULL,
  Country VARCHAR(20) NOT NULL,
  Email VARCHAR(60) NOT NULL,
  Mobile_number INT NOT NULL,
  User_Profile_ID INT NOT NULL,
  DOB DATE NOT NULL,
  User_ID INT NOT NULL,
  PRIMARY KEY (User_Profile_ID),
  FOREIGN KEY (User_ID) REFERENCES User(User_ID)
);

CREATE TABLE Education
(
  university VARCHAR(60) NOT NULL,
  Qualifications VARCHAR(60) NOT NULL,
  Degree VARCHAR(45) NOT NULL,
  Education_ID INT NOT NULL,
  User_Profile_ID INT NOT NULL,
  PRIMARY KEY (Education_ID),
  FOREIGN KEY (User_Profile_ID) REFERENCES User_Profile(User_Profile_ID)
);

CREATE TABLE Work_Experience
(
  Company_Name VARCHAR(60) NOT NULL,
  Postition VARCHAR(60) NOT NULL,
  Year_of_experience INT NOT NULL,
  job_name VARCHAR(60) NOT NULL,
  Experience_ID INT NOT NULL,
  User_Profile_ID INT NOT NULL,
  PRIMARY KEY (Experience_ID),
  FOREIGN KEY (User_Profile_ID) REFERENCES User_Profile(User_Profile_ID)
);

CREATE TABLE _Adiminstrator
(
  Admin_ID INT NOT NULL,
  Admin_Name VARCHAR(60) NOT NULL,
  Admin_Password VARCHAR(60) NOT NULL,
  Admin_Email VARCHAR(60) NOT NULL,
  Jobs_ID INT NOT NULL,
  User_ID INT NOT NULL,
  PRIMARY KEY (Admin_ID),
  FOREIGN KEY (Jobs_ID) REFERENCES Jobs(Jobs_ID),
  FOREIGN KEY (User_ID) REFERENCES User(User_ID)
);

CREATE TABLE Bulk_Email
(
  Email_content VARCHAR(60) NOT NULL,
  Email_Title VARCHAR(60) NOT NULL,
  Email_ID INT NOT NULL,
  Admin_ID INT NOT NULL,
  PRIMARY KEY (Email_ID),
  FOREIGN KEY (Admin_ID) REFERENCES _Adiminstrator(Admin_ID)
);

