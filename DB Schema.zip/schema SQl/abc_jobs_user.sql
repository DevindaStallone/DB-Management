-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: abc_jobs
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `UserId` int NOT NULL AUTO_INCREMENT,
  `FullName` varchar(45) NOT NULL,
  `Address` varchar(60) NOT NULL,
  `Gender` varchar(20) NOT NULL,
  `DOB` date NOT NULL,
  `Email` varchar(45) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `City` varchar(45) NOT NULL,
  `Country` varchar(45) NOT NULL,
  `MobileNumber` int NOT NULL,
  PRIMARY KEY (`UserId`),
  KEY `id_user` (`UserId`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (2,'Victor Pontin','Suite 32','Male','2022-04-17','vpontin1@livejournal.com','emXj1jYMbq','Wyszogród','Poland',320529),(3,'Jdavie Durnin','PO Box 86759','Male','2023-01-08','jdurnin2@cmu.edu','e0wunQ9R','Xincun','China',941914),(4,'Taffy Jakuszewski','PO Box 36997','Female','2022-07-03','tjakuszewski3@weebly.com','UcHWrE9Vz','‘Ibrī','Oman',360560),(5,'Berenice Welfair','PO Box 7230','Female','2022-03-08','bwelfair4@hatena.ne.jp','jAwLqdOH','Seremban','Malaysia',39460),(6,'Hyacinth Brittles','4th Floor','Female','2022-11-26','hbrittles5@wisc.edu','gyYHR3jtCV','Conceição do Jacuípe','Brazil',782674),(7,'Nevin Fagg','Apt 686','Male','2022-07-18','nfagg6@friendfeed.com','bPZVsT','Potet','Indonesia',840409),(8,'Bellina Pilipyak','PO Box 41346','Female','2022-05-23','bpilipyak7@disqus.com','X4B3BY1o','Ryczów','Poland',663760),(9,'Kariotta Clardge','Apt 329','Female','2022-04-27','kclardge8@ifeng.com','Rs8vJxexFHJ','San Clemente','Chile',323684),(10,'Kermy Passingham','Suite 32','Male','2022-04-17','kpassingham9@blinklist.com','E4MDTz786Kv','Motala','Sweden',812207);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-31 15:07:03
