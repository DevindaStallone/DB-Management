INSERT INTO user (UserId, FullName, Address, Gender, DOB, Email, Password, City, Country, MobileNumber)
VALUES (1, 'devinda','noway,london', 'male', 2003-02-15, 'djhs@gmail.com', 'dweda145', 'norway', 'london', 123456789);

SELECT FullName, Email, Password FROM user 
WHERE Email = 'devindastallone@gmail.com'
AND Password = 1234;
       
SELECT FullName, Email, Password
   FROM user_profile 
WHERE email = 'devindastallone@gmail.com';

SELECT FullName, Address, Email, MobileNumber
  FROM user_profile
WHERE FullName='Devinda Stallone'

UPDATE user
SET Password='12345'
WHERE Email='devindastallone@gmail.com'

UPDATE User
SET FullName='Stallone'
Where UserID=1;

UPDATE User
SET MobileNumber='New Number'
Where UserID=1

SELECT Email FROM user
WHERE Email='devindastallone@gmail.com';

DELETE FROM user 
WHERE MobileNumber=12354678
